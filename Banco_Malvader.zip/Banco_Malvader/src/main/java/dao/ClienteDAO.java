/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Sarinha
 */
import model.Cliente;
import java.sql.*;

public class ClienteDAO {

    // Método para salvar um novo cliente no banco
    public void salvarCliente(Cliente cliente) {
        String sql = "INSERT INTO cliente (id_usuario) VALUES (?)";

        try (Connection conexao = ConnectionFactory.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, cliente.getIdUsuario());
            stmt.executeUpdate();
            System.out.println("Cliente cadastrado com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

