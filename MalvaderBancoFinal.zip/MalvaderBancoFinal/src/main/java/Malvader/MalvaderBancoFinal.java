/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Malvader;

/**
 *
 * @author Sarinha
 */

import view.LoginView;

public class MalvaderBancoFinal {
    public static void main(String[] args) {
        // Inicia a interface gráfica do login
        new LoginView().setVisible(true);
    }
}
