/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

/**
 *
 * @author Sarinha
 */
import dao.ConnectionFactory;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;

public class DBUtil {

    public static List<List<Object>> executarQuery(String sql, Object... params) {
        List<List<Object>> resultado = new ArrayList<>();
        try (Connection conexao = ConnectionFactory.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }

            ResultSet rs = stmt.executeQuery();
            ResultSetMetaData metaData = rs.getMetaData();
            int colunas = metaData.getColumnCount();

            while (rs.next()) {
                List<Object> linha = new ArrayList<>();
                for (int i = 1; i <= colunas; i++) {
                    linha.add(rs.getObject(i));
                }
                resultado.add(linha);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultado;
    }
}

