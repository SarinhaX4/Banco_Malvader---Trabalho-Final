/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Sarinha
 */
public class ContaCorrente extends Conta {
    private double limite;

    public void depositar(double valor) {
        setSaldo(getSaldo() + valor);
    }

    public boolean sacar(double valor) {
        if (getSaldo() + limite >= valor) {
            setSaldo(getSaldo() - valor);
            return true;
        }
        return false;
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }
}
