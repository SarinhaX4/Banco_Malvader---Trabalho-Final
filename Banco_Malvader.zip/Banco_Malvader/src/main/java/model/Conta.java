/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
/**
 *
 * @author Sarinha
 */
public abstract class Conta {
    private int numeroConta; // Número único da conta
    private String agencia; // Agência associada à conta
    private double saldo; // Saldo disponível na conta
    private int cliente; // Cliente associado à conta

    /**
     * Método abstrato para realizar um depósito na conta.
     * @param valor Valor a ser depositado.
     */
    public abstract void depositar(double valor);

    /**
     * Método abstrato para realizar um saque da conta.
     * @param valor Valor a ser sacado.
     * @return true se o saque for realizado com sucesso; false caso contrário.
     */
    public abstract boolean sacar(double valor);

    /**
     * Consulta o saldo atual da conta.
     * @return O saldo atual.
     */
    public double consultarSaldo() {
        return saldo;
    }

    // Getters e Setters
    public int getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(int numeroConta) {
        this.numeroConta = numeroConta;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public int getCliente() {
        return cliente;
    }

    public void setCliente(int cliente) {
        this.cliente = cliente;
    }
}
