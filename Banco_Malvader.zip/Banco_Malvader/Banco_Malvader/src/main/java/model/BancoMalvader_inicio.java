/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Sarinha
 */
public class BancoMalvader_inicio {
    private String nome;

    public static void main(String[] args) {
        BancoMalvader_inicio banco = new BancoMalvader_inicio();
        banco.iniciarSistema();
    }

    public void iniciarSistema() {
        System.out.println("Sistema Banco Malvader iniciado!");
    }
}

