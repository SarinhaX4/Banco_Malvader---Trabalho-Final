/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Sarinha
 */
public class ContaPoupanca extends Conta {
    private double taxaRendimento; // Taxa de rendimento para a poupança

    public double calcularRendimento() {
        return getSaldo() * (taxaRendimento / 100);
    }

    public void depositar(double valor) {
        setSaldo(getSaldo() + valor);
    }

    public boolean sacar(double valor) {
        if (getSaldo() >= valor) {
            setSaldo(getSaldo() - valor);
            return true;
        }
        return false;
    }

    public double getTaxaRendimento() {
        return taxaRendimento;
    }

    public void setTaxaRendimento(double taxaRendimento) {
        this.taxaRendimento = taxaRendimento;
    }
}

