/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Sarinha
 */
public class Cliente extends Usuario {
    private String senha;

    public double consultarSaldo() {
        System.out.println("Consultando saldo...");
        return 0.0; // Implementar lógica real
    }

    public void depositar(double valor) {
        System.out.println("Depositando: " + valor);
    }

    public boolean sacar(double valor) {
        System.out.println("Sacando: " + valor);
        return true; // Implementar lógica real
    }

    public String consultarExtrato() {
        System.out.println("Consultando extrato...");
        return ""; // Implementar lógica real
    }

    public double consultarLimite() {
        System.out.println("Consultando limite...");
        return 0.0; // Implementar lógica real
    }

    // Getters e Setters
    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    @Override
    public boolean login(String senha) {
        return this.senha.equals(senha);
    }

    @Override
    public void logout() {
        System.out.println("Cliente desconectado.");
    }

    @Override
    public String consultarDados() {
        return "Nome: " + getNome() + ", CPF: " + getCpf();
    }
}
