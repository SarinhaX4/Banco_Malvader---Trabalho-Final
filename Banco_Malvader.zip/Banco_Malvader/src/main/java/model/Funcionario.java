/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Sarinha
 */
public class Funcionario extends Usuario {
    private String codigoFuncionario;
    private String cargo;
    private String senha;
    

    public void abrirConta(Conta conta) {
        System.out.println("Conta aberta com sucesso!");
    }

    public void encerrarConta(Conta conta) {
        System.out.println("Conta encerrada com sucesso!");
    }

    public Conta consultarDadosConta(int numeroConta) {
        System.out.println("Consultando dados da conta...");
        return null; // Implementar lógica real de consulta
    }

    public Cliente consultarDadosCliente(int idCliente) {
        System.out.println("Consultando dados do cliente...");
        return null; // Implementar lógica real de consulta
    }

    public void alterarDadosConta(Conta conta) {
        System.out.println("Dados da conta alterados!");
    }

    public void alterarDadosCliente(Cliente cliente) {
        System.out.println("Dados do cliente alterados!");
    }

    public void cadastrarFuncionario(Funcionario funcionario) {
        System.out.println("Funcionário cadastrado com sucesso!");
    }

    public void gerarRelatorioMovimentacao() {
        System.out.println("Relatório de movimentação gerado!");
    }

    // Getters e Setters
    public String getCodigoFuncionario() {
        return codigoFuncionario;
    }

    public void setCodigoFuncionario(String codigoFuncionario) {
        this.codigoFuncionario = codigoFuncionario;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    @Override
    public boolean login(String senha) {
        return this.senha.equals(senha);
    }

    @Override
    public void logout() {
        System.out.println("Funcionário desconectado.");
    }

    @Override
    public String consultarDados() {
        return "Nome: " + getNome() + ", CPF: " + getCpf() + ", Cargo: " + cargo;
    }
}
